<img width="1774" height="887" alt="已生1成图像_1" src="https://github.com/user-attachments/assets/9e4e770f-4e4e-4134-8071-262f894bc2c8" />


# CubeTT（Chrome 扩展）

输入想法后自动优化为高质量提示词，支持本地保存、搜索、导出，以及 LLM 接口接入。

## 主要功能

- 场景提示词：写作、营销、编程、学习、职场
- 一键优化生成（本地增强 + 可选远程 LLM）
- 一键复制优化结果
- 保存提示词到本地目录（JSON）
- 搜索并回填已保存提示词
- 导出全部提示词
- 亮/暗主题与配色切换
- 顶部问号弹窗（扩展说明 + 作者信息）

## 安装方式（小白版）

1. 下载本仓库源码（`Code -> Download ZIP`）并解压。
2. 打开 Chrome，进入：`chrome://extensions/`
3. 右上角打开“开发者模式”。
4. 点击“加载已解压的扩展程序”。
5. 选择本项目文件夹（包含 `manifest.json` 的目录）。
6. 安装完成后，点击扩展图标即可使用。

## 如何使用

1. 在“输入你的想法/问题”里输入需求。
2. 选择场景标签（写作/营销/编程/学习/职场）。
3. 点击“优化生成”。
4. 可点击“一键复制”复制结果。
5. 可点击“保存该提示词”保存到你选择的本地目录。

## LLM 接口配置（可选）

1. 点击右上角设置图标。
2. 填写：
   - API 接口地址
   - API Key
   - 模型名称
3. 点击“保存接口设置”。
4. 顶部 LLM 状态点会显示连接状态。

> 提示：如果接口在本地 `file://` 直接预览时失败，通常是浏览器跨域限制；请在扩展环境中测试。


## 常见问题

### 1）点击扩展没反应

- 先到 `chrome://extensions/` 点击“刷新”
- 确认 `manifest.json` 存在且未损坏

### 2）保存目录看不到完整系统路径

- 浏览器 File System Access API 出于安全限制，不会直接暴露完整路径

### 3）图标更新不生效

- 刷新扩展
- 不行就“移除”后重新“加载已解压的扩展程序”（图标缓存常见）

## 项目结构

```text
Cube-prompt/
├─ manifest.json
├─ popup.html
├─ popup.css
├─ popup.js
├─ background.js
├─ assets/
├─ icons/
└─ 备份/
```

## License

MIT（见 `LICENSE`）

## Star History

[![Star History Chart](https://api.star-history.com/svg?repos=2797565800/CubeTT&type=Date)](https://star-history.com/#2797565800/CubeTT&Date)
